'use client'

import { useEffect } from 'react'

export function LogFetcher() {
  useEffect(() => {
    async function fetchLogs(url: string, elementId: string) {
      try {
        const response = await fetch(url)
        const logs = await response.json()
        const element = document.getElementById(elementId)
        if (element) {
          element.innerHTML = logs.map((log: string) => `<p class="mb-1 text-gray-300">${log}</p>`).join('')
        }
      } catch (error) {
        console.error(`Error fetching logs from ${url}:`, error)
      }
    }

    function updateLogs() {
      fetchLogs('http://localhost:5001/logs', 'ven-logs')
      fetchLogs('http://localhost:5002/logs', 'vtn-logs')
    }

    updateLogs() // Initial fetch
    const intervalId = setInterval(updateLogs, 2000) // Fetch logs every 2 seconds

    // Cleanup function to clear the interval when the component unmounts
    return () => clearInterval(intervalId)
  }, []) // Empty dependency array means this effect runs once on mount

  return null // This component doesn't render anything
}

