"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, XCircle } from "lucide-react"

export function SignalControls() {
  const [showMessage, setShowMessage] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [signalName, setSignalName] = useState("")
  const [signalType, setSignalType] = useState("")

  const handleSendSignal = async () => {
    if (signalName && signalType) {
      try {
        const currentTimeUTC = new Date().toISOString()
        const response = await fetch("http://localhost:5002/send_events", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            ven_id: "ven_id_123",
            signal_name: signalName,
            signal_type: signalType,
            intervals: [
              {
                dtstart: currentTimeUTC,
                duration: "PT10M", // ISO 8601 duration format for 10 minutes
                signal_payload: 1,
              },
            ],
          }),
        })

        if (!response.ok) {
          throw new Error("Network response was not ok")
        }

        setIsSuccess(true)
      } catch (error) {
        console.error("Error sending signal:", error)
        setIsSuccess(false)
      }

      setShowMessage(true)
      setTimeout(() => {
        setShowMessage(false)
        setSignalName("")
        setSignalType("")
      }, 3000)
    }
  }

  return (
    <div className="w-full max-w-xs mx-auto space-y-2 p-3 bg-gray-800 rounded-lg border border-gray-700 relative">
      <Select value={signalName} onValueChange={setSignalName}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Select signal name" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="simple">Simple</SelectItem>
          <SelectItem value="moderate">Moderate</SelectItem>
          <SelectItem value="complex">Complex</SelectItem>
        </SelectContent>
      </Select>
      <Select value={signalType} onValueChange={setSignalType}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Select signal type" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="level">Level</SelectItem>
          <SelectItem value="price">Price</SelectItem>
          <SelectItem value="setpoint">Setpoint</SelectItem>
        </SelectContent>
      </Select>
      <Button className="w-full" onClick={handleSendSignal} disabled={!signalName || !signalType}>
        Send Signal
      </Button>
      {showMessage && (
        <div
          className={`absolute inset-0 flex items-center justify-center ${isSuccess ? "bg-green-500" : "bg-red-500"} bg-opacity-90 rounded-lg transition-opacity duration-300`}
        >
          <div className="text-white flex items-center">
            {isSuccess ? <CheckCircle className="mr-2" /> : <XCircle className="mr-2" />}
            {isSuccess ? "Signal sent successfully!" : "Failed to send signal"}
          </div>
        </div>
      )}
    </div>
  )
}

