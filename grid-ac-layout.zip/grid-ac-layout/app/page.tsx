"use client"

import Image from "next/image"
import { LogFetcher } from "./components/LogFetcher"
import { SignalControls } from "./components/SignalControls"
import { useEffect } from "react"

export default function Home() {
  useEffect(() => {
    // Set dark mode
    document.documentElement.classList.add("dark")
  }, [])

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold text-center mb-8">VTN and VEN Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="flex flex-col items-center">
            <h2 className="text-2xl font-bold mb-4">VTN (server)</h2>
            <div className="relative w-full aspect-square max-w-[300px] mb-4">
              <Image
                src="/placeholder.svg?height=300&width=300"
                alt="Electricity Grid"
                fill
                className="object-cover rounded-lg"
              />
            </div>
          </div>
          <div className="flex flex-col items-center">
            <h2 className="text-2xl font-bold mb-4">VEN (client)</h2>
            <div className="relative w-full aspect-square max-w-[300px] mb-4">
              <Image
                src="/placeholder.svg?height=300&width=300"
                alt="Air Conditioner"
                fill
                className="object-cover rounded-lg"
              />
            </div>
          </div>
        </div>
        <div className="mb-8">
          <SignalControls />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div
            id="vtn-logs"
            className="w-full h-64 md:h-96 border border-gray-700 rounded-lg p-4 overflow-auto bg-gray-800 text-gray-300"
          ></div>
          <div
            id="ven-logs"
            className="w-full h-64 md:h-96 border border-gray-700 rounded-lg p-4 overflow-auto bg-gray-800 text-gray-300"
          ></div>
        </div>
      </div>
      <LogFetcher />
    </div>
  )
}

