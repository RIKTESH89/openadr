import asyncio
from datetime import datetime, timezone, timedelta
from openleadr import OpenADRServer, enable_default_logging
from functools import partial
from flask import Flask, jsonify
from flask_cors import CORS
import threading

enable_default_logging()

# Logging mechanism
logs = []

# Flask app for serving logs
app = Flask(__name__)
CORS(app)

@app.route('/logs', methods=['GET'])
def get_logs():
    return jsonify(logs[-100:])  # Serve the last 10 logs

async def on_create_party_registration(registration_info):
    if registration_info['ven_name'] == 'ven123':
        ven_id = 'ven_id_123'
        registration_id = 'reg_id_123'
        logs.append(f"VEN registered with ven_id: {ven_id} and registration_id: {registration_id}")
        return ven_id, registration_id
    else:
        logs.append(f"Failed registration attempt with ven_name: {registration_info['ven_name']}")
        return False

async def on_register_report(ven_id, resource_id, measurement, unit, scale,
                             min_sampling_interval, max_sampling_interval):
    callback = partial(on_update_report, ven_id=ven_id, resource_id=resource_id, measurement=measurement)
    sampling_interval = min_sampling_interval
    logs.append(f"Registered report from VEN {ven_id} for resource {resource_id}")
    return callback, sampling_interval

async def on_update_report(data, ven_id, resource_id, measurement):
    for time, value in data:
        logs.append(f"VEN {ven_id} reported {measurement} = {value} at time {time} for resource {resource_id}")

async def event_response_callback(ven_id, event_id, opt_type):
    logs.append(f"VEN {ven_id} responded to Event {event_id} with: {opt_type}")

server = OpenADRServer(vtn_id='MYVTN')

server.add_handler('on_create_party_registration', on_create_party_registration)
server.add_handler('on_register_report', on_register_report)

current_time_utc = datetime.now(timezone.utc)

server.add_event(
    ven_id='ven_id_123',
    signal_name='simple',
    signal_type='level',
    intervals=[
        {
            'dtstart': current_time_utc,
            'duration': timedelta(minutes=10),
            'signal_payload': 1
        }
    ],
    callback=event_response_callback
)

def start_flask():
    app.run(port=5002)

loop = asyncio.get_event_loop()
loop.create_task(server.run())

# Run Flask in a separate thread
threading.Thread(target=start_flask, daemon=True).start()

loop.run_forever()
