import asyncio
from datetime import timedelta
from openleadr import OpenADRClient, enable_default_logging
from flask import Flask, jsonify
from flask_cors import CORS
import threading

enable_default_logging()

# Logging mechanism
logs = []

# Flask app for serving logs
app = Flask(__name__)
CORS(app)

@app.route('/logs', methods=['GET'])
def get_logs():
    return jsonify(logs[-100:])  # Serve the last 10 logs

async def collect_report_value():
    logs.append("Collected report value: 1.23")
    return 1.23

async def handle_event(event):
    logs.append(f"Event ID: {event['event_descriptor']['event_id']}")
    logs.append(f"Event Status: {event['event_descriptor']['event_status']}")
    logs.append(f"Created Date: {event['event_descriptor']['created_date_time']}")
    logs.append(f"Start Time: {event['active_period']['dtstart']}")
    logs.append(f"Duration: {event['active_period']['duration']}")
    logs.append(f"Signal Name: {event['event_signals'][0]['signal_name']}")
    logs.append(f"Signal Payload: {event['event_signals'][0]['intervals'][0]['signal_payload']}")
    logs.append(f"Target VEN ID: {event['targets'][0]['ven_id']}")
    logs.append(f"Response Required: {event['response_required']}")
    return 'optIn'

client = OpenADRClient(ven_name='ven123',
                       vtn_url='http://localhost:8080/OpenADR2/Simple/2.0b')

client.add_report(callback=collect_report_value,
                  resource_id='device001',
                  measurement='voltage',
                  sampling_rate=timedelta(seconds=50))

client.add_handler('on_event', handle_event)

def start_flask():
    app.run(port=5001)

loop = asyncio.get_event_loop()
loop.create_task(client.run())

# Run Flask in a separate thread
threading.Thread(target=start_flask, daemon=True).start()

loop.run_forever()
